# نظام إدارة مواقع العمل - Android

هذه النسخة تغلف ملف HTML الحالي داخل تطبيق Android باستخدام WebView.
ملف النظام الأصلي محفوظ كما هو داخل:
app/src/main/assets/index.html

للبناء في Android Studio:
1. افتح مجلد المشروع.
2. انتظر اكتمال Gradle Sync.
3. اختر Build > Build APK(s).
4. ستجد APK داخل app/build/outputs/apk/.

يتطلب اتصال الإنترنت لأن النظام يستخدم Supabase.
